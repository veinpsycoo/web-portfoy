@echo off
cd /d "%~dp0" || exit /b 1
if not exist ".venv-live\Scripts\python.exe" (
  echo Once KUR.cmd dosyasini calistirin.
  pause
  exit /b 1
)
".venv-live\Scripts\python.exe" meydan.py
if errorlevel 1 (
  pause
  exit /b 1
)
set "halayMode=mendil=hediye&studio=1"
set "tarayici="
for %%P in ("%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe") do if not defined tarayici if exist %%P set "tarayici=%%~P"
if not defined tarayici for %%K in (HKLM HKCU) do if not defined tarayici for /f "tokens=2,*" %%A in ('reg query "%%K\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" /ve 2^>nul ^| find "REG_"') do if exist "%%B" set "tarayici=%%B"
if not defined tarayici for /f "delims=" %%W in ('where chrome 2^>nul') do if not defined tarayici set "tarayici=%%W"
if not defined tarayici for %%K in (HKLM HKCU) do if not defined tarayici for /f "tokens=2,*" %%A in ('reg query "%%K\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" /ve 2^>nul ^| find "REG_"') do if exist "%%B" set "tarayici=%%B"
if not defined tarayici (
  echo Chrome ya da Edge bulunamadi. Google Chrome kurup tekrar deneyin.
  pause
  exit /b 1
)
echo Tarayici: %tarayici%
start "" "%tarayici%" "--user-data-dir=%LOCALAPPDATA%\HalayMeydani-Yayin" --disable-features=CalculateNativeWinOcclusion --no-first-run --no-default-browser-check --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-renderer-backgrounding --autoplay-policy=no-user-gesture-required --window-size=720,1280 "--app=http://127.0.0.1:18765/?%halayMode%"
